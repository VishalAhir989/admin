// rootReducer.js
import { combineReducers } from "redux";
import signReducer from "./Reducer";

const rootReducer = combineReducers({
    signReducer
});

export default rootReducer;
